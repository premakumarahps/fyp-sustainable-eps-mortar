================================================================================
Group 24 Final Year Research Project: Raw Experimental Data Repository
Department of Materials Science and Engineering | University of Moratuwa
================================================================================

Project Title:
Synergistic Effects of Rice Husk Ash and Polypropylene Fiber on the Performance 
of Modified Expanded Polystyrene Cement Mortar

Authors:
- H.P.S. Premakumara (Index: 210494D)
- K. Mayoorathan (Index: 210381E)
- Supervisor: Eng. S.P. Guluwita

Contents:
1. Phase_1_Base_Mortar_Experimental_Data.csv (CCF DoE w/b vs s/b matrix)
2. Phase_2_Modified_Lightweight_Mortar_Data.csv (CCF DoE RHA% vs EPS% matrix)
3. Phase_3_ITZ_SEM_EDS_Elemental_Analysis.csv (SEM-EDS Ca/Si diagnostics)
4. Phase_4_Physical_Coating_Validation_Data.csv (PVAc core-shell recovery)
5. Phase_5_PP_Fiber_Toughening_Data.csv (PP micro-fiber balling threshold)
6. MSand_Granulometric_Sieve_Analysis.csv (BS 882 Zone M grading compliance)
7. RHA_EDS_Smart_Quant_Oxide_Composition.csv (Table 21 ASTM C618 pozzolan)

All datasets are finalized, cross-checked, and authenticated against the 
149-page master dissertation.
================================================================================
